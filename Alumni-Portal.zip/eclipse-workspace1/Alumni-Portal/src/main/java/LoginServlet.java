import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(LoginServlet.class.getName());

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Retrieve login data
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish MySQL connection
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/alumni", "root", "");

            // SQL query to check user credentials
            String query = "SELECT * FROM users WHERE email = ? AND password = ?";
            PreparedStatement ps = con.prepareStatement(query);

            // Set query parameters
            ps.setString(1, email);
            ps.setString(2, password);  // Hash the password if using hashing during registration

            // Execute query
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                // Login successful, redirect to main page
                response.sendRedirect("main.html");
            } else {
                out.println("<h3>Invalid email or password. Please try again.</h3>");
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error during login", e);
            out.println("<h3>Error: " + e.getMessage() + "</h3>");
        } finally {
            out.close();  // Ensure the PrintWriter is closed
        }
    }
}
